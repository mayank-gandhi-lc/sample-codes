package com.appsdeveloperblog.app.ws.ui.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	
	@RequestMapping(method = RequestMethod.POST, consumes = { "multipart/form-data" }, value = "/getData")
	@ResponseBody
	public void myUser(@RequestPart("jcr:data") String data ) {
		System.out.println(data);
	}
	
	@GetMapping(path = "/sample")
	public String myUser2() {
		return "sample get";
		
		
	}
	
}
	
	